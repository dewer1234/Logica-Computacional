
Brandon Padilla Ruiz
brandon.padilla.r@ciencias.unam.mx
312139805


Para realizar el ejercicio semanal ocupé todo lo visto en deducción natural en lógica propocisional y LPO, el asistente de hecho era facil de usar y te ayudaba mucho probar lineal por linea si vas por buen camino o no, aunque en el ejercicio 6 de LPO no era posible demostrar que eso era verdadero, trate de hacerlo con deducción natural a mano y de ninguna forma podía llegar al resultado.