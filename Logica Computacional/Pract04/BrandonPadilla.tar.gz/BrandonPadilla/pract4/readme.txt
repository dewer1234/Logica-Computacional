
Brandon Padilla Ruiz
312139805
brandon.padilla.r@ciencias.unam.mx

La práctica la hice con lo que vimos en clase acerca de prolog, en el problema del abuelo decidi que poner como hecho que el personaje es padre de la hija de su mujer para que se pudiera unificar y me diera que el personaje es su propio abuelo, mientras que en el problema de los libros de Albert no tuve mucho problema para hacer el ejercicio, solo era cuestion de especificar cada cosa que dice el problema.		
