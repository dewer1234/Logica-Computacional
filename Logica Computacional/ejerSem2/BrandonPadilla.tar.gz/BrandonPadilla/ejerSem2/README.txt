
Brandon Padilla Ruiz
brandon.padilla.r@ciencias.unam.mx
312139805

En la práctica ocupé las definiciones recursivas que hemos visto desde estructuras discretas, ocupé una función auxiliar conct que nos ayuda a concatenar listas, esto me ayudó a hacer la especificación de la reversa de una lista.