
Brandon Padilla Ruiz
312139805
brandon.padilla.r@ciencias.unam.mx

Para hacer la practica hice uso del conocimiento en el curso, para la función vars utilicé una función auxiliar ya definida en Haskell que es nub, la cual elimina las repeticiones en una lista y regresa la lista sin repeticiones, para la función estados utilicé vars y potencia, para la función potencia utilicé la definición de potencia y finalmente para la función tautología hice una función auxiliar llama aplicaF para aplicar interp a cada elemento de una lista, esto con el fin de aplicarla en estados por que estados regresa una lista de listas de estados, es decir, aplicaremos interp a cada lista de estados.