Brandon Padilla Ruiz
312139805
brandon.padilla.r@ciencias.unam.mx

La práctica la hice con lo que vimos en clase para transformar fórmulas en Forma Normal Clausular, para fnn utilicé una funcion auxiliar "aux" con el fin de poner menos codigo en fnn y solo contemplar los casos principales en ella.